function myCanvas() {
    this.canvas = document.querySelector("canvas");
    // 获取实时数据
    this.inps = document.querySelectorAll(".box ul li input");
    // 输入完毕按钮
    this.trueBtn = document.querySelector(".box .trueBtn");
    // 显示数据按钮
    this.showBtn = document.querySelector(".box .showBtn");
    // 判断月份详情有木有显示
    this.isShow = true;
    this.myP = document.querySelector(".box p");
    this.canvas.width = 650;
    this.canvas.height = 450;
    this.canvas.style.backgroundColor = "#eee";
    this.ctx = this.canvas.getContext("2d");
    // y轴区间 [25,425]  原本坐标区间
    this.sectionY = 425;

}

// 初始化方法
myCanvas.prototype.init = function () {
    // 清空画布
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    // 调用数据更新方法
    this.newData();
    // 背景方法
    this.bgImages();
    // 边框方法
    this.myBorder();
    // x, y轴方法
    this.XY_axis();
    // 绘制月份
    this.mouth();
    // 折线
    this.brokenLine();
    // 动画
    // this.setDataHeight();

}

// 数据更新方法
myCanvas.prototype.newData = function () {
    this.points = [
        {
            name: "1月",
            x: 50,
            y: this.inps[0].value || 260,
        },
        {
            name: "2月",
            x: 100,
            y: this.inps[1].value || 20
        },
        {
            name: "3月",
            x: 150,
            y: this.inps[2].value || 34
        },
        {
            name: "4月",
            x: 200,
            y: this.inps[3].value || 56
        },
        {
            name: "5月",
            x: 250,
            y: this.inps[4].value || 250
        },
        {
            name: "6月",
            x: 300,
            y: this.inps[5].value || 62
        },
        {
            name: "7月",
            x: 350,
            y: this.inps[6].value || 85
        },
        {
            name: "8月",
            x: 400,
            y: this.inps[7].value || 150
        },
        {
            name: "9月",
            x: 450,
            y: this.inps[8].value || 263
        },
        {
            name: "10月",
            x: 500,
            y: this.inps[9].value || 198
        },
        {
            name: "11月",
            x: 550,
            y: this.inps[10].value || 398
        },
        {
            name: "12月",
            x: 600,
            y: this.inps[11].value || 100
        }

    ]
}
// 点击事件
myCanvas.prototype.myClick = function () {
    // 缓存this
    var _this = this;
    // 数值输入完毕确认时间
    this.trueBtn.onclick = function () {

        for (var i = 0; i < _this.inps.length; i++) {
            // 判断input的内容是否为空
            if (_this.inps[i].value !== "") {
                // 判断是否在区间里面  用户取值区间
                if (_this.inps[i].value > 400 || _this.inps[i].value < 0) {
                    _this.myP.style.color = "red";
                    _this.myP.innerHTML = "请输入[0,400]这个区间的任意数,谢谢配合!";

                    // 有一个不满足停止函数并且返回第几月份不符合条件
                    return (function (suoyin) {
                        alert(suoyin + 1 + "月份的数据不在这个区间内,请重新输入");
                    })(i);
                }
            }
        }
        // 调用初始化方法
        _this.init();

        // 清除数据
        for (key in _this.inps) {
            _this.inps[key].value = "";
        }
        // 关闭每个月的详细数值
        _this.showBtn.innerHTML = "显示每个月的具体数值";
        _this.isShow = true;

        _this.myP.innerHTML = "输入正确,谢谢配合!";
        _this.myP.style.color = "green";

    }

    // 显示每个月的具体数值确认事件
    this.showBtn.onclick = function () {
        if (_this.isShow) {
            _this.mouthText();
            _this.showBtn.innerHTML = "关闭每个月的具体数值";
            // for( key in _this.inps){
            //     _this.inps[key].value = "";
            // }
            _this.isShow = false;
        } else {
            _this.init();
            _this.showBtn.innerHTML = "显示每个月的具体数值";
            _this.isShow = true;
        }
    }
}
// 绘制边框
myCanvas.prototype.myBorder = function () {
    // 调用绘制线的方法
    this.myLink(0, 0, this.canvas.width, 0, 2);
    this.myLink(this.canvas.width, 0, this.canvas.width, this.canvas.height, 2);
    this.myLink(this.canvas.width, this.canvas.height, 0, this.canvas.height, 2);
    this.myLink(0, this.canvas.height, 0, 0, 2);
}
// 绘制背景方法
myCanvas.prototype.bgImages = function () {
    // 横线
    for (var y = 0; y <= this.canvas.height; y = y + 12.5) {
        // 调用绘制线的方法
        this.myLink(0, y, this.canvas.width, y, 1, "#ccc")
    }
    // 竖线
    for (var x = 0; x <= this.canvas.width; x = x + 12.5) {
        // 调用绘制线的方法
        this.myLink(x, 0, x, this.canvas.height, 1, "#ccc")
    }

}
// 绘制 x, y 轴的方法
myCanvas.prototype.XY_axis = function () {
    // x轴 调用绘制线的方法
    this.myLink(25, 425, 625, 425, 2);
    // 调用三角形方法
    this.polygon(638.5, 425, 625, 432, 625, 419);

    // y轴 调用绘制线的方法
    this.myLink(25, 25, 25, 425, 2);
    // 调用三角形方法
    this.polygon(25, 12.5, 19, 25, 32, 25);

}
// 绘制月份的方法和 y轴文本
myCanvas.prototype.mouth = function () {

    for (var i = 0; i < 12; i++) {
        var numX = i * 50;
        // 调用文本方法
        this.myText(i + 1 + "月", 37.5 + numX, 443);
        // 绘制线
        this.myLink(numX + 50, 428, numX + 50, 422, 2);
    }
    // y 轴
    // 调用文本方法
    this.myText("400", 2, 30, "blue", "12px 宋体");
    this.myText("0", 10, 430, "blue", "12px 宋体");
}

// 绘制文本的方法 ( 公用 )
myCanvas.prototype.myText = function (text, x, y, color, size_textStyle) {
    this.ctx.beginPath();
    this.ctx.font = size_textStyle || "14px 宋体";
    this.ctx.strokeStyle = color || "purple";
    this.ctx.strokeText(text, x, y);
    this.ctx.stroke();
}
// 绘制线的方法 ( 公用 )
myCanvas.prototype.myLink = function (x0, y0, x1, y1, linkWidth, color) {
    this.ctx.beginPath();
    this.ctx.moveTo(x0, y0);
    this.ctx.lineTo(x1, y1);
    this.ctx.lineWidth = linkWidth || 1;
    this.ctx.strokeStyle = color || "#000";
    this.ctx.stroke();
}
// 绘制多边形的方法 ( 公用 )
myCanvas.prototype.polygon = function (x0, y0, x1, y1, x2, y2, color) {

    this.ctx.beginPath();
    this.ctx.moveTo(x0, y0);
    this.ctx.lineTo(x1, y1);
    this.ctx.lineTo(x2, y2);
    this.ctx.lineTo(x0, y0);
    this.ctx.strokeStyle = color || "#000";
    this.ctx.fillStyle = color || "#000";
    this.ctx.fill();
    // this.ctx.stroke();
    this.ctx.stroke();
}
// 绘制矩形方法 ( 公用 )
myCanvas.prototype.rectangle = function (x, y, w, h, color) {
    this.ctx.beginPath();
    this.ctx.rect(x, y, w, h);
    this.ctx.fillStyle = color || "#000";
    this.ctx.fill();
    this.ctx.closePath();
}

// 绘制数据折线的方法
myCanvas.prototype.brokenLine = function () {
    // 循环遍历数据
    for (var i = 0; i < this.points.length - 1; i++) {
        // 图形原本坐标是倒序  变为正序使用公式 : 最大取值 - 用户输入的值 = 当前坐标位置
        // this.sectionY 是最大取值 400
        // this.sectionY - this.points[i].y = 当前坐标
        // 调用线方法
        this.myLink(this.points[i].x, this.sectionY - this.points[i].y, this.points[i + 1].x, this.sectionY - this.points[i + 1].y, 1, "red");

    }
    for (var i = 0; i < this.points.length; i++) {
        // 调用矩形方法
        this.rectangle(this.points[i].x - 3, this.sectionY - this.points[i].y - 3, 6, 6, "red");
    }

}
// 显示每个月具体数值的方法
myCanvas.prototype.mouthText = function () {
    for (var i = 0; i < this.points.length; i++) {
        // 调用文本函数
        this.myText(this.points[i].y, this.points[i].x - 3, this.sectionY - this.points[i].y - 3, "blue", "12px 宋体");
        // 在对应的input里面显示具体数值
        // this.inps[i].value = this.points[i].y;
    }
}
// 绘制动画函数
// myCanvas.prototype.setDataHeight = function(){
//     var i = 1;
//     var _this = this;
//     // 当前 y坐标的间隔值
//     var ySpace = 0;
//     var timer = setInterval( function(){
//         i++
//         if( i >= 50 ){
//             clearInterval(timer);
//         }
//         // _this.myLink( _this.points[0].x+i-1, _this.sectionY - _this.points[0].y+i, _this.points[0].x+i, _this.sectionY - _this.points[0].y+i, 1,"red");
//         // _this.myLink( 100+i-1, 100+i, 100+i, 100+i, 1, "red");
//         // ( 50, 190 ) ==> ( x1, x1 );
//         // ( 100, 430 ) ==> ( x2, y2 );
//         ySpace = ( 430 - 190) / 50 *i;
//         console.log(190+ySpace);
//         _this.myLink( 50+i-1, 190+ySpace, 50+i, 190+ySpace, 1, "red");

//     },15)
// }

var myCtx = new myCanvas();
myCtx.init();
myCtx.myClick();